import glob
import json
from pathlib import Path
from struct import unpack, pack
import os
import sys

files = glob.glob("CHECKED/*.json")

"""
Source of mzx0_compress():
https://github.com/Hintay/PS-HuneX_Tools/blob/ad40001f9ea6c44ecfe75db723fccb5b942d0462/tools/mzx/comp_mzx0.py
"""
def mzx0_compress(f, inlen, xorff=False):
    """Compress a block of data.
    """
    dout = bytearray(b'MZX0')
    dout.extend(pack('<L', inlen))

    key = 0xFFFFFFFF if xorff else 0
    while inlen >= 0x80:
        # 0xFF literal, write plaintext input 0x80 bytes // 0xFF = 0xFC+0x03 // (0xFC >> 2 + 1) => 0x40 times 2-byte pairs
        dout.extend(b'\xFF')
        for i in range(0x20):
            dout.extend(pack('<L', unpack('<L', f.read(0x4))[0] ^ key))
        inlen -= 0x80

    key = 0xFF if xorff else 0
    if inlen >= 0x02: # 0x02-0x7F remainder
        dout.extend(bytes([ ((inlen >> 1) - 1) * 4 + 3 ]))
        for i in range((inlen >> 1) * 2):
            dout.extend(bytes([ ord(f.read(1)) ^ key ]))
        inlen -= (inlen >> 1) * 2

    if inlen == 0x01: # pad with useless character
        dout.extend(b'\x03')
        dout.extend(bytes([ ord(f.read(1)) ^ key ]))
        dout.extend(b'\x00')

    return dout

def BreakLine(string: str) -> str:
	linesize = 66
	if (string.find("<r") != -1):
		print("This string uses illegal characters!")
		print(string)
		sys.exit()
	string = string.split(" ")
	begin = 0
	new_string = ""
	for i in range(len(string) + 1):
		temp_string = " ".join(string[begin:i])
		if (len(temp_string.encode("shift_jis_2004")) > linesize):
			new_string += " ".join(string[begin:i-1]) + "\n"
			begin = i - 1
	new_string += " ".join(string[begin:])

	count = new_string.count("\n")
	if (count > 2):
		print("This string has more than 3 lines:")
		print(new_string)
	return new_string

for i in range(len(files)):
	print(files[i])

	file = open(files[i], "r", encoding="UTF-8")
	DUMP = json.load(file)
	file.close()

	script = open(f"Parsed/{Path(files[i]).stem}.txt", "r", encoding="shift_jis_2004")
	buffer = script.read()
	script.close()
	my_lines = buffer.split(";")
	while (my_lines[-1] == ""):
		my_lines.pop()

	OFFSETS = []
	offset = 0
	for x in range(len(my_lines)):
		OFFSETS.append(offset)
		offset += len(my_lines[x].encode("shift_jis_2004")) + 1
	
	JUMP_TABLE = []

	script_itr = 0
	dump_itr = 0
	DICT = {}
	while (dump_itr < len(DUMP)):
		new_line = ""
		line = my_lines[script_itr]
		if (line[1:5] == "MTLK"):
			try:
				DUMP[dump_itr]['ENG_NAME']
			except:
				print("Expected NAME, didn't got it.")
				print("CMD ID: %d" % dump_itr)
				print(my_lines[script_itr-4].rstrip())
				print(my_lines[script_itr-3].rstrip())
				print(my_lines[script_itr-2].rstrip())
				print(my_lines[script_itr-1].rstrip())
				print(line)
				print(my_lines[script_itr+1].rstrip())
				print(my_lines[script_itr+2].rstrip())
				print(my_lines[script_itr+3].rstrip())
				print(my_lines[script_itr+4].rstrip())
				print(DUMP[dump_itr])
				sys.exit()
			if (DUMP[dump_itr]['NAME'] != None and DUMP[dump_itr]['NAME'] != line[8:-1]):
				print("NAMES NOT MATCHING!")
				print(DUMP[dump_itr]['NAME'])
				print(line[8:-1])
				print(my_lines[script_itr-4].rstrip())
				print(my_lines[script_itr-3].rstrip())
				print(my_lines[script_itr-2].rstrip())
				print(my_lines[script_itr-1].rstrip())
				print(line)
				sys.exit()
			if (DUMP[dump_itr]['ENG_NAME'] != None):
				my_lines[script_itr] = f"_MTLK(1,{DUMP[dump_itr]['ENG_NAME'].replace('?', '}').replace('!', '{').replace(')', '_')})"
			script_itr += 1
			line = my_lines[script_itr]
			assert(line[1:3] == "ZM")
			my_lines[script_itr] = "_ZM%05x(%s)" % (DUMP[dump_itr]['ID'], BreakLine(DUMP[dump_itr]['ENG_STRING'].replace('?', '}').replace('!', '{').replace(')', '_').replace('” ', '”').replace(' “', '“')))
			new_line = " "
		elif (line[1:3] == "ZM"):
			my_lines[script_itr] = "_ZM%05x(%s)" % (DUMP[dump_itr]['ID'], BreakLine(DUMP[dump_itr]['ENG_STRING'].replace('?', '}').replace('!', '{').replace(')', '_').replace('” ', '”').replace(' “', '“')))
			new_line = " "
		elif (line[1:5] == "SELR"):
			my_lines[script_itr] = f"_SELR({DUMP[dump_itr]['ID']},{DUMP[dump_itr]['ENG_STRING'].replace('?', '}').replace('!', '{').replace(')', '_').replace(', ', '，')}))"
			new_line = " "
		elif (line[1:5] == "WHST"):
			new_line = "_WHST()"
			my_lines[script_itr] = f"_WHST({DUMP[dump_itr]['ENG_STRING'].replace('?', '}').replace('!', '{').replace(')', '_').replace(', ', '，').replace('” ', '”').replace(' “', '“')}))"
		elif (line[1:5] == "XSTX"):
			pos = line.find(DUMP[dump_itr]['STRING'])
			new_line = line.find(",")
			my_lines[script_itr] = f"_XSTX{line[5:new_line+1]}{DUMP[dump_itr]['ENG_STRING'].replace('?', '}').replace('!', '{').replace(')', '_').replace('” ', '”').replace(' “', '“')}{line[line.find(',', new_line+1):]}"
		if (new_line != ""):
			dump_itr += 1
		script_itr += 1
	
	for x in range(len(my_lines)):
		my_lines[x] += ";"

	for x in range(len(my_lines)):
		line = my_lines[x]
		if (x != 0):
			if (line[1:3] in ["ZZ", "ZY"]):
				new_line = ""
				ID1 = line[3:6]
				NAME = line[9:-2]
				new_line = NAME
				new_line += " " * (21 - len(NAME))
				new_line += ID1 + ","
				new_line += "%05x" % (len("".join(my_lines[:x]).encode("shift_jis_2004")))
				JUMP_TABLE.append(new_line)
				continue

	new_script = open(f"Patched/{Path(files[i]).stem}.txt", "w", encoding="shift_jis_2004", newline="")
	new_script.writelines(my_lines)
	new_script.close()

	script = open(f"Patched/{Path(files[i]).stem}.txt", "rb")
	buffer = script.read()
	script.close()

	new_script = open(f"Patched/{Path(files[i]).stem}.txt", "wb")
	new_script.write(buffer.replace(b"\x81\x5f", b"\\"))
	length = new_script.tell()
	new_script.close()

	script = open(f"Patched/{Path(files[i]).stem}.txt", "rb")
	data = mzx0_compress(script, length, True)
	script.close()

	os.remove(f"Patched/{Path(files[i]).stem}.txt")

	new_script = open(f"Patched/{Path(files[i]).stem}.mzx0", "wb")
	new_script.write(data)
	new_script.close()	

	new_script = open(f"Patched/JUMPS/{Path(files[i]).stem}.txt", "w", encoding="shift_jis_2004", newline="\r\n")
	new_script.write("\n".join(JUMP_TABLE))
	new_script.write("\n")
	new_script.close()
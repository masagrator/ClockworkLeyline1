import glob
import json
from pathlib import Path
import sys

files = glob.glob("SPLITTED/*.json")

for i in range(len(files)):
	print(Path(files[i]).stem)
	NEW_DUMP = []
	file1 = open(files[i], "r", encoding="UTF-8")
	file2 = open(f"Parsed2/{Path(files[i]).stem}.json", "r", encoding="UTF-8")

	PC_DUMP = json.load(file1)
	NX_DUMP = json.load(file2)

	file1.close()
	file2.close()

	keys = list(NX_DUMP.keys())

	for x in range(len(keys)):
		PC_itr = 0
		for y in range(len(NX_DUMP[keys[x]]["MESSAGES"])):
			if "NAME" in NX_DUMP[keys[x]]["MESSAGES"][y].keys():
				try:
					NX_DUMP[keys[x]]["MESSAGES"][y]["NAME"] != PC_DUMP[keys[x]][PC_itr+1]["JPN"]
				except:
					print("Something went wrong with index!")
					print("DICT: %s" % keys[x])
					sys.exit()
				if NX_DUMP[keys[x]]["MESSAGES"][y]["NAME"] != PC_DUMP[keys[x]][PC_itr+1]["JPN"]:
					print("NAME NOT MATCHED!")
					print("EXPECTED: %s" % NX_DUMP[keys[x]]["MESSAGES"][y]["NAME"])
					print("GOT: %s" % PC_DUMP[keys[x]][PC_itr+1]["JPN"])
					print("DICT: %s" % keys[x])
					print("ITR NX: %d, PC: %d" % (y, PC_itr+1))
					sys.exit()
				NX_DUMP[keys[x]]["MESSAGES"][y]["ENG_NAME"] = PC_DUMP[keys[x]][PC_itr+1]["ENG"]
			try:
				NX_DUMP[keys[x]]["MESSAGES"][y]["STRING"] != PC_DUMP[keys[x]][PC_itr]["JPN"]
			except:
				print("Something went wrong with index!")
				print("DICT: %s" % keys[x])
				sys.exit()
			if NX_DUMP[keys[x]]["MESSAGES"][y]["STRING"] != PC_DUMP[keys[x]][PC_itr]["JPN"]:
				if (NX_DUMP[keys[x]]["MESSAGES"][y]["STRING"][-2:] == "@n"):
					PC_DUMP[keys[x]][PC_itr]["JPN"] += "@n"
				if NX_DUMP[keys[x]]["MESSAGES"][y]["STRING"] != PC_DUMP[keys[x]][PC_itr]["JPN"]:
					print("STRING NOT MATCHED!")
					print("EXPECTED: %s" % NX_DUMP[keys[x]]["MESSAGES"][y]["STRING"])
					print("GOT: %s" % PC_DUMP[keys[x]][PC_itr]["JPN"])
					print("DICT: %s" % keys[x])
					print("ITR NX: %d, PC: %d" % (y, PC_itr))
					sys.exit()
				else:
					PC_DUMP[keys[x]][PC_itr]["ENG"] += "@n"
			NX_DUMP[keys[x]]["MESSAGES"][y]["ENG_STRING"] = PC_DUMP[keys[x]][PC_itr]["ENG"]
			if "ENG_NAME" in NX_DUMP[keys[x]]["MESSAGES"][y].keys():
				PC_itr += 1
			PC_itr += 1
			NEW_DUMP.append(NX_DUMP[keys[x]]["MESSAGES"][y])
	
	new_file = open(f"CHECKED/{Path(files[i]).stem}.json", "w", encoding="UTF-8")
	json.dump(NEW_DUMP, new_file, indent="\t", ensure_ascii=False)
	new_file.close()

